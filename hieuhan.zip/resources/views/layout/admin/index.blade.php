@extends('layout.admin.master')

@section('sub-content')
	Dashboard
@endsection
@section('action')
	Thống kê
@endsection