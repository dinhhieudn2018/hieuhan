<?php $__env->startSection('sub-content'); ?>
  Dịch vụ
<?php $__env->stopSection(); ?>
<?php $__env->startSection('action'); ?>
  Danh sách
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="padding-top: 30px;width: 100%">
       
       <div id="content" class="table-responsive">
  <table class="table table-bordered table-hover">
   <thead>
      <tr style="background-color: #3c8dbc;color:white;">
        <th class="text-center">STT</th>
        <th class="text-center">Tên dịch vụ</th>
        <th class="text-center">Giá</th>
        <th class="text-center">Tình trạng</th>
        
        <th class="text-center">
          <a href="<?php echo e(route('service.create')); ?>" class="btn btn-sm btn-success">
              <span class="glyphicon glyphicon-plus"></span>&nbsp;Thêm
          </a>
        </th>
      </tr>
  </thead>
  <tbody>
   <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><?php echo e($value->id); ?></td>
        <td class="text-center"><?php echo e($value->name); ?></td>
        <td class="text-center"><?php echo e($value->price); ?></td>
        <td class="text-center">
          <?php if($value->status == 1): ?>
            <span class="label label-success label-draft">Hiển thị</span>
          <?php else: ?>
            <span class="label label-primary label-draft">Ẩn</span>
          <?php endif; ?>
        </td>
        <td class="text-center">
          <a href="<?php echo e(route('service.edit',$value->id)); ?>" class="btn btn-info btn-xs" style="margin:2px !important">
              <i class="fa fa-eye fa-fw"></i><span>Sửa</span>
          </a>
          
            <a href="<?php echo e(route('destroy.service',$value->id)); ?>" class="btn btn-danger btn-xs  del" style="margin:2px !important" >
              <i class="glyphicon glyphicon-trash fa-fw"></i><span>Xóa</span>
          </a>
         
          
        </td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>

   
</table>
<div class="pull-right"><?php echo e($services->links()); ?></div>
       </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>