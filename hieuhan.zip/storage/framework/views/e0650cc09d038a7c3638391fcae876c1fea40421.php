<?php $__env->startSection('sub-content'); ?>
  Khách hàng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('action'); ?>
  Danh sách
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="padding-top: 30px;width: 100%">
       
       <div id="content" class="table-responsive">
            <table class="table table-bordered table-hover">
   <thead>
      <tr style="background-color: #3c8dbc;color:white;">
        <th class="text-center">STT</th>
        <th class="text-center">Tên khách hàng</th>
        <th class="text-center">Email</th>
        <th class="text-center">Số điện thoại</th>
        <th class="text-center">Địa chỉ</th>
        <th class="text-center">Lịch hẹn</th>
        <th class="text-center">Ngày đặt</th>
        <th class="text-center">Tin nhắn</th>
        <th class="text-center">Tình trạng</th>
        
        <th class="text-center">
          <a href="<?php echo e(route('customer.index')); ?>" class="btn btn-sm btn-success">
              <span class="glyphicon glyphicon-plus"></span>&nbsp;Thêm
          </a>
        </th>
      </tr>
  </thead>
  <tbody>
   <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><?php echo e($value->id); ?></td>
        <td class="text-center"><?php echo e($value->name); ?></td>
        <td class="text-center"><?php echo e($value->email); ?></td>
        <td class="text-center"><?php echo e($value->phone); ?></td>
        <td class="text-center"><?php echo e($value->address); ?></td>
        <td class="text-center"><?php echo e($value->appointment_schedule); ?></td>
        <td class="text-center"><?php echo e(Carbon\Carbon::createFromTimestamp(strtotime($value->date))->format('j-m-Y')); ?></td>
        <td class="text-center"><?php echo e($value->message); ?></td>
        <td class="text-center">
          <?php if($value->status == 0): ?>
            <span class="label label-success label-draft">Chờ xác nhận</span>
          <?php else: ?>
            <span class="label label-primary label-draft">Đã xác nhận</span>
          <?php endif; ?>
        </td>
        <td class="text-center">
          <a href="<?php echo e(route('customer.edit',$value->id)); ?>" class="btn btn-info btn-xs" style="margin:2px !important">
              <i class="fa fa-eye fa-fw"></i><span>Xem</span>
          </a>
          
            <a href="<?php echo e(route('cus.destroy',$value->id)); ?>" class="btn btn-danger btn-xs  del" style="margin:2px !important" >
              <i class="glyphicon glyphicon-trash fa-fw"></i><span>Xóa</span>
          </a>
         
          
        </td>
    </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
  </tbody>

   
</table>
<div class="pull-right"><?php echo e($customers->links()); ?></div>
       </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>