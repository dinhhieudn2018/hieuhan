<!--Price -->
	  <div class="gallery-w3layouts" id="price">
		<div class="container-fluid">
			<h5 class="title-w3" id="price-table">Bảng giá</h5>
			 <div class="container">
      

      <div class="row">
        <div class="col-12">
          <div class="price-table table-responsive">
            <table class="table table-borderless mb-0">
              <thead>
                <tr>
                  <th scope="col">Tên dịch vụ</th>
                 
                  <th scope="col">Giá</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($price->name); ?></th>
                  
                  <td><?php echo e($price->price); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>

        
      </div>
    </div>
			
			
		</div>
	</div>
	<!-- End price -->