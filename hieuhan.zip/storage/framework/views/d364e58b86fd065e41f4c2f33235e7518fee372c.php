<!-- gallery -->
	<div class="gallery-w3layouts" id="portfolio">
		<div class="container-fluid">
			<h5 class="title-w3" id="image">Hình ảnh</h5>
			<?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-3 gallery-columns">
				
				<div class="gal_grid_outer">
					<a title="We’re pleased to offer a wide range of dental services."
					    href="upload/img/<?php echo e($img->image); ?>">
						<div class="gal_grid_outer1">
							<img src="upload/img/<?php echo e($img->image); ?>" alt=" " class="img-responsive" style="width: 400px; height: 220px" />
							<div class="gallery_grid_pos">
								<h3>
									<span><?php echo e($img->title); ?></span>
									
								</h3>
							</div>
						</div>
					</a>
				</div>

				
				
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- //gallery -->