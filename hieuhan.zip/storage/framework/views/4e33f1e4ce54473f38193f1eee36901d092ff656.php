<!-- testimonials -->
	<div class="test">
		<div class="container">
			<h5 class="title-w3">Khách hàng phản hồi</h5>
			<div class=" test-gr">
				<div class=" test-gri1">
					<div id="owl-demo2" class="owl-carousel">
						<div class="agile">
							<?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-6 test-grid">
								<div class="test-grid1-agileinfo">
									<img src="upload/img/<?php echo e($fb->image); ?>" alt="" class="img-r">
									<p><?php echo $fb->description; ?></p>
									<h4><?php echo e($fb->name_customer); ?></h4>
									<span><?php echo e($fb->type); ?></span>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<div class="clearfix"></div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- testimonials -->