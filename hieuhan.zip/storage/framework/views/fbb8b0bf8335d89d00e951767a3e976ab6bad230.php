<?php $__env->startSection('sub-content'); ?>
    Hình ảnh hoạt động
<?php $__env->stopSection(); ?>
<?php $__env->startSection('action'); ?>
    Sửa
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="container" style="padding-top: 30px">
   <div class="col-lg-12" style="padding-bottom:120px">
        
        <form action="<?php echo e(route('image.update',$image->id)); ?>" method="POST" enctype="multipart/form-data">
          <?php echo method_field('put'); ?>
         <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">  
         <?php echo e(csrf_field()); ?>          
         <div class="row">
            <div class="col-md-6">
              
               <div class="form-group">
                  <label>Tiêu đề ảnh</label>
                  <input class="form-control" type="text" name="title" placeholder="Nhập tiêu đề ảnh vd: tẩy trắng răng, chỉnh nha..." value="<?php echo e($image->title); ?>">
               </div>
               <div class="form-group">
                  <label>Tình trạng</label>
                  
                  <select class="form-control" name="status">
                        <option value="1" <?php if($image->status == 1): ?> selected="" <?php endif; ?>>Hiển thị</option>
                        <option value="0" <?php if($image->status == 0): ?> selected="" <?php endif; ?>>Không hiển thị</option>                       
                  </select>
               </div>
               
            </div>
           <div class="col-md-6">
              <div class="form-group">
                    <label for="image">Hình ảnh</label>
                    <input type="file" name="image"  class="form-control">
                    <img src="upload/img/<?php echo e($image->image); ?>" style="width: 100px; height: 100px">
                </div> 
           </div>
           
         </div>
         <div class="text-center">
            <button type="submit" class="btn btn-success">Lưu</button>
            <a href="<?php echo e(URL::previous()); ?>" class="btn btn-default">Quay lại</a>
         </div>
        </form>
   </div>
   <!-- Your code to create an instance of Fine Uploader and bind to the DOM/template
      ====================================================================== -->
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>